import { NextResponse } from 'next/server';
import nodemailer from 'nodemailer';

export async function GET() {
  try {
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    // Step 1: Verify the connection
    await transporter.verify();
    console.log('SMTP connection verified successfully!');

    // Step 2: Send a test email
    await transporter.sendMail({
      from: `"Bag Hub Test" <${process.env.EMAIL_USER}>`,
      to: process.env.EMAIL_USER, // Send to yourself
      subject: 'Bag Hub - Email Test ✅',
      html: '<h1>If you see this, NodeMailer is working correctly!</h1>',
    });

    return NextResponse.json({ success: true, message: 'Test email sent! Check your inbox.' });
  } catch (error: any) {
    console.error('Email test failed:', error);
    return NextResponse.json({ success: false, error: error.message, code: error.code }, { status: 500 });
  }
}
