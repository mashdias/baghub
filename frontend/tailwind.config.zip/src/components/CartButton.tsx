"use client";

import Link from "next/link";
import { useCart } from "@/context/CartContext";
import { usePathname } from "next/navigation";

export default function CartButton() {
  const { itemCount, isMounted } = useCart();
  const pathname = usePathname();

  // Never show the cart button inside the Admin Panel
  if (pathname?.startsWith("/admin")) return null;

  // Prevent hydration error by rendering a skeleton or default state first
  if (!isMounted) {
    return (
      <div className="px-5 py-2 bg-primary text-white rounded-full font-medium shadow-lg shadow-primary/20 opacity-80 cursor-wait">
        Cart (0)
      </div>
    );
  }

  return (
    <Link href="/cart" className="px-5 py-2 bg-primary hover:bg-primary-dark text-white rounded-full font-medium transition-colors shadow-lg shadow-primary/20 flex items-center gap-2">
      Cart ({itemCount})
    </Link>
  );
}
